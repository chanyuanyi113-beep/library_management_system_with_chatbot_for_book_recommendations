<?php
// includes/header.php
// Usage: set $active_tab before including, e.g. $active_tab = 'catalog';

// IMPORTANT: For AJAX requests, don't output ANY HTML - CHECK THIS FIRST
$is_ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$active_tab = $active_tab ?? 'catalog';

// ── Database connection ───────────────────────────────────────────────────────
require_once __DIR__ . '/../db.php';

// ── Logged-in user ────────────────────────────────────────────────────────────
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

$logged_in_username = $_SESSION['username'];

$stmt = $pdo->prepare('SELECT id, name, user_type_id FROM users WHERE username = ? LIMIT 1');
$stmt->execute([$logged_in_username]);
$user_row = $stmt->fetch();

if ($user_row) {
    $logged_in_user_id = $user_row['id'];
    $user_name = $user_row['name'];
    $logged_in_user_type_id = $user_row['user_type_id'];
    
    $typeStmt = $pdo->prepare('SELECT type FROM user_type WHERE id = ?');
    $typeStmt->execute([$logged_in_user_type_id]);
    $userType = $typeStmt->fetch();
    $logged_in_user_type = $userType['type'] ?? 'user';
} else {
    $logged_in_user_id = 2;
    $user_name = 'Guest';
    $logged_in_user_type = 'user';
}

// For AJAX requests, STOP HERE - don't output any HTML
// Clear any output buffers and return
if ($is_ajax) {
    // Clean any existing output buffers
    while (ob_get_level()) {
        ob_end_clean();
    }
    // Return without any HTML output
    return;
}

// ── STATS and HTML output only for non-AJAX requests below ───────────────────
// (All the HTML generation code goes here - only for non-AJAX requests)

$stmt = $pdo->query('SELECT COUNT(*) FROM books');
$total_books = (int) $stmt->fetchColumn();

$stmt = $pdo->query('SELECT COUNT(*) FROM books WHERE available = 1');
$available_books = (int) $stmt->fetchColumn();

$stmt = $pdo->query('SELECT COUNT(*) FROM book_categories');
$category_count = (int) $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE user_type_id = 3");
$member_count = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare(
    'SELECT COUNT(*) FROM borrow_requests
     WHERE user_id = ? AND book_status_id IN (1, 2)'
);
$stmt->execute([$logged_in_user_id]);
$my_borrowed_count = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare(
    'SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0'
);
$stmt->execute([$logged_in_user_id]);
$unread_notifs = (int) $stmt->fetchColumn();

// Due date notifications
$due_date_check = date('Y-m-d', strtotime('+3 days'));
$stmt = $pdo->prepare(
    'SELECT br.id, b.title AS book_title
     FROM borrow_requests br
     JOIN books b ON b.id = br.book_id
     WHERE br.user_id = ? AND br.book_status_id IN (1, 2) AND DATE(br.due_date) = ?
     AND NOT EXISTS (
         SELECT 1 FROM notifications n
         WHERE n.user_id = ? AND n.message LIKE CONCAT("%", b.title, "%") AND DATE(n.created_at) = CURDATE()
     )'
);
$stmt->execute([$logged_in_user_id, $due_date_check, $logged_in_user_id]);
$due_books = $stmt->fetchAll();

$criteria_stmt = $pdo->prepare(
    'SELECT id FROM notifications_criteria 
     WHERE title_id = (SELECT id FROM notifications_title WHERE title = ?) 
     AND type_id = (SELECT id FROM notifications_type WHERE type = ?) LIMIT 1'
);
$criteria_stmt->execute(['Book Due Soon', 'info']);
$due_soon_criteria_id = $criteria_stmt->fetchColumn();

foreach ($due_books as $due_book) {
    if ($due_soon_criteria_id) {
        $insert_notif = $pdo->prepare(
            'INSERT INTO notifications (user_id, criteria_id, message)
             VALUES (?, ?, ?)'
        );
        $insert_notif->execute([
            $logged_in_user_id,
            $due_soon_criteria_id,
            'Your borrowed book "' . $due_book['book_title'] . '" is due in 3 days (' . date('M j, Y', strtotime($due_date_check)) . ').'
        ]);
    }
}

$my_books_label = $my_borrowed_count > 0
    ? "My Books ($my_borrowed_count)"
    : 'My Books';

$tabs = [
    'catalog'       => ['label' => 'Book Catalog',    'href' => 'main.php'],
    'mybooks'       => ['label' => $my_books_label,   'href' => 'my_books.php'],
    'history'       => ['label' => 'History',         'href' => 'borrow_history.php'],
    'profile'       => ['label' => 'Profile',         'href' => 'profile.php'],
    'notifications' => ['label' => 'Notifications',   'href' => 'notifications.php'],
];

if ($logged_in_user_type === 'admin') {
    $tabs['admin'] = ['label' => 'Admin Panel', 'href' => 'admin.php'];
}

if ($logged_in_user_type === 'librarian') {
    $tabs['librarian'] = ['label' => 'Librarian Dashboard', 'href' => 'librarians_main.php'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Library Hub</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- ===== NAVBAR ===== -->
<nav class="navbar">
  <div class="navbar-brand">
    <div class="logo-icon">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
      </svg>
    </div>
    <div class="brand-text">
      <h1>Library Hub</h1>
      <span>Digital Library Management</span>
    </div>
  </div>
  <div class="navbar-actions">
    <a href="notifications.php" class="notif-btn">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
        <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
      </svg>
      <?php if ($unread_notifs > 0): ?>
        <span class="badge"><?php echo $unread_notifs > 99 ? '99+' : $unread_notifs; ?></span>
      <?php endif; ?>
    </a>
    <div class="user-info">
      <a href="profile.php" class="profile-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
          <circle cx="12" cy="7" r="4"/>
        </svg>
        <?= htmlspecialchars($user_name) ?>
        <?php if ($logged_in_user_type !== 'user'): ?>
          <span style="font-size: 11px; background: #e5e7eb; padding: 2px 6px; border-radius: 12px; margin-left: 8px;">
            <?= htmlspecialchars($logged_in_user_type) ?>
          </span>
        <?php endif; ?>
      </a>
    </div>
    <a href="logout.php" class="logout-btn" onclick="return confirm('Are you sure you want to logout?');">Logout</a>
  </div>
</nav>

<!-- ===== STATS BAR ===== -->
<div class="stats-section">

  <div class="stat-card">
    <div class="stat-card-header">
      <span class="stat-label">Total Books</span>
      <svg class="stat-icon" width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
      </svg>
    </div>
    <div class="stat-value"><?= number_format($total_books) ?></div>
    <div class="stat-sub">Across all categories</div>
  </div>

  <div class="stat-card">
    <div class="stat-card-header">
      <span class="stat-label">Available Books</span>
      <svg class="stat-icon" width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
        <polyline points="9 11 12 14 22 4"/>
      </svg>
    </div>
    <div class="stat-value"><?= number_format($available_books) ?></div>
    <div class="stat-sub">Ready to borrow</div>
  </div>

  <div class="stat-card">
    <div class="stat-card-header">
      <span class="stat-label">Book Categories</span>
      <svg class="stat-icon" width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M4 6h16"/>
        <path d="M4 12h16"/>
        <path d="M4 18h16"/>
      </svg>
    </div>
    <div class="stat-value"><?= number_format($category_count) ?></div>
    <div class="stat-sub">Total categories</div>
  </div>

  <div class="stat-card">
    <div class="stat-card-header">
      <span class="stat-label">Members</span>
      <svg class="stat-icon" width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
        <circle cx="9" cy="7" r="4"/>
        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
      </svg>
    </div>
    <div class="stat-value"><?= number_format($member_count) ?></div>
    <div class="stat-sub">Active users</div>
  </div>

</div>

<!-- ===== PAGE TABS ===== -->
<div class="page-tabs">
  <?php foreach ($tabs as $key => $tab): ?>
    <a href="<?= $tab['href'] ?>"
       class="<?= $active_tab === $key ? 'active' : '' ?>">
      <?= htmlspecialchars($tab['label']) ?>
    </a>
  <?php endforeach; ?>
</div>

<div class="main-content">