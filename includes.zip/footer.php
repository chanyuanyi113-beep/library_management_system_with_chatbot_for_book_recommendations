<?php
// includes/footer.php
// Check user membership for chatbot access
$is_premium = false;
$can_use_chatbot = false;
$has_favorite_categories = false;  // ← ADD THIS LINE

if ($logged_in_user_id) {
    $user_stmt = $pdo->prepare('SELECT membership_type_id, user_type_id FROM users WHERE id = ? LIMIT 1');
    $user_stmt->execute([$logged_in_user_id]);
    $user_data = $user_stmt->fetch();
    $membership_type_id = $user_data['membership_type_id'] ?? 1;
    $user_type_id = $user_data['user_type_id'] ?? 3;
    
    // Premium users (membership_type_id = 2) OR Admin/Librarian (user_type_id = 1 or 2) can actually use
    $can_use_chatbot = ($membership_type_id == 2 || $user_type_id == 1 || $user_type_id == 2);
    $is_premium = ($membership_type_id == 2);
    
    // ← ADD THIS BLOCK to check favorite categories
    if ($can_use_chatbot && $user_type_id == 3) {
        $fav_stmt = $pdo->prepare('
            SELECT COUNT(*) 
            FROM user_favorite_categories 
            WHERE user_id = ?
        ');
        $fav_stmt->execute([$logged_in_user_id]);
        $has_favorite_categories = $fav_stmt->fetchColumn() > 0;
    }
} else {
    $can_use_chatbot = false;
}

// Load chat history
$chat_messages = $_SESSION['chat_messages'] ?? [];
?>
</div><!-- /.main-content -->

<!-- ===== CHATBOT WIDGET ===== -->
<button class="chatbot-toggle" id="chatbotToggle" title="Book Recommendations">
  💬
</button>

<div class="chatbot-window" id="chatbotWindow">
  <div class="chatbot-header">
    <div>
      <h3>📚 Book Assistant</h3>
      <p>Get personalised book recommendations</p>
    </div>
    <button class="chatbot-close" id="chatbotClose">✕</button>
  </div>
  <div class="chatbot-messages" id="chatMessages">
    <div class="chat-msg bot">
      Hi! I'm your Library Assistant. Ask me for book recommendations or help finding books. 📖
    </div>
    <div class="quick-replies" id="quickReplies">
        <div class="quick-reply-group">
            <div class="quick-reply-title">⭐ Quick Actions:</div>
            <button class="quick-reply" data-message="what's popular">🔥 Popular Books</button>
                <button class="quick-reply" data-message="highly rated">⭐ Highly Rated Books</button>
            <button class="quick-reply" data-message="newly added">🆕 Newly Added Books</button>
            <button class="quick-reply" data-message="how to borrow">📖 How to Borrow</button>
            <button class="quick-reply" data-message="personalized recommendations">🎯 My Recommendations</button>
            <button class="quick-reply" data-action="searchByTitle">🔍 Search by Title</button>
            <button class="quick-reply" data-action="searchByAuthor">✍️ Search by Author</button>
        </div>
        <div class="quick-reply-group">
            <div class="quick-reply-title">📚 By Genre:</div>
            <div id="genre-buttons-loading">Loading genres...</div>
        </div>
    </div>
  </div>
  <div class="chatbot-input-area">
    <input type="text" class="chatbot-input" id="chatInput"
           placeholder="Or type your question here..." />
    <button class="chatbot-send" id="chatSend">➤</button>
  </div>
</div>

<style>
/* Quick reply bubbles styling */
.quick-replies {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-top: 12px;
    padding: 4px 0;
}

.quick-reply-group {
    background: #f9fafb;
    border-radius: 12px;
    padding: 10px;
    border: 1px solid #e5e7eb;
}

.quick-reply-title {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.quick-reply {
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 20px;
    padding: 6px 14px;
    margin: 4px 6px 4px 0;
    font-size: 12px;
    color: #374151;
    cursor: pointer;
    transition: all 0.2s ease;
    display: inline-block;
}

.quick-reply:hover {
    background: #1976d2;
    color: white;
    border-color: #1976d2;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.quick-reply:active {
    transform: translateY(0);
}

/* Typing indicator */
.typing-indicator {
    display: flex;
    gap: 4px;
    align-items: center;
    padding: 10px 14px;
}

.typing-indicator span {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #9ca3af;
    display: inline-block;
    animation: typing 1.4s infinite ease-in-out both;
}

.typing-indicator span:nth-child(1) { animation-delay: -0.32s; }
.typing-indicator span:nth-child(2) { animation-delay: -0.16s; }
.typing-indicator span:nth-child(3) { animation-delay: 0s; }

@keyframes typing {
    0%, 80%, 100% { transform: scale(0.8); opacity: 0.5; }
    40% { transform: scale(1.2); opacity: 1; }
}

/* Message animations */
.chat-msg {
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Go button in chat */
.chat-go-btn {
    background: #1976d2;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 6px 12px;
    font-size: 11px;
    cursor: pointer;
    margin-top: 6px;
    font-weight: 500;
    transition: all 0.2s ease;
}

.chat-go-btn:hover {
    background: #1565c0;
    transform: translateY(-1px);
}

/* Scrollbar styling */
.chatbot-messages::-webkit-scrollbar {
    width: 6px;
}

.chatbot-messages::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 3px;
}

.chatbot-messages::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 3px;
}

.chatbot-messages::-webkit-scrollbar-thumb:hover {
    background: #a8a8a8;
}
</style>

<script>
const toggle = document.getElementById('chatbotToggle');
const win    = document.getElementById('chatbotWindow');
const close  = document.getElementById('chatbotClose');
const send   = document.getElementById('chatSend');
const input  = document.getElementById('chatInput');
const msgs   = document.getElementById('chatMessages');
let isLoading = false;
let hasSentMessage = false;

// Load chat history
const initialMessages = <?php echo json_encode($chat_messages); ?>;
const canUseChatbot = <?php echo $can_use_chatbot ? 'true' : 'false'; ?>;

// Store the last bot message element to scroll to it
let lastBotMessageElement = null;

function formatMessage(text) {
    // Convert markdown-style bold to HTML
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Convert line breaks to <br>
    text = text.replace(/\n/g, '<br>');
    return text;
}

function appendMsg(text, role) {
    const d = document.createElement('div');
    d.className = 'chat-msg ' + role;
    
    if (role === 'bot') {
        d.innerHTML = formatMessage(text);
        // Attach listeners to any go buttons in this message
        const buttons = d.querySelectorAll('.chat-go-btn');
        buttons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const bookTitle = this.getAttribute('data-book');
                if (bookTitle) {
                    window.location.href = 'main.php?search=' + encodeURIComponent(bookTitle);
                }
            });
        });
        lastBotMessageElement = d;
    } else {
        d.innerHTML = formatMessage(text);
    }
    
    msgs.appendChild(d);
    
    // Scroll to show the new message, but keep the last bot message in view
    if (role === 'bot') {
        // For bot messages, scroll to show the message with some padding
        d.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        msgs.scrollTop = msgs.scrollHeight;
    }
    
    return d;
}

// Load existing messages from session
initialMessages.forEach(msg => {
    appendMsg(msg.text, msg.role);
});
if (initialMessages.length > 0) {
    hasSentMessage = true;
}

toggle.addEventListener('click', () => {
    if (!canUseChatbot) {
        alert('Book recommendations chatbot is only available for Premium members.\n\nUpgrade your membership to Premium to unlock this feature!');
        return;
    }
    win.classList.toggle('open');
    if (win.classList.contains('open')) {
        setTimeout(() => {
            input.focus();
            // If no messages have been sent in this session, show quick replies
            if (!hasSentMessage) {
                const quickRepliesDiv = document.getElementById('quickReplies');
                if (quickRepliesDiv) {
                    quickRepliesDiv.style.display = 'flex';
                }
            }
        }, 300);
    }
});

close.addEventListener('click',  () => win.classList.remove('open'));

function showTypingIndicator() {
    const indicator = document.createElement('div');
    indicator.className = 'chat-msg bot typing-indicator';
    indicator.id = 'typingIndicator';
    indicator.innerHTML = '<span>.</span><span>.</span><span>.</span>';
    msgs.appendChild(indicator);
    msgs.scrollTop = msgs.scrollHeight;
}

function removeTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

function hideQuickReplies() {
    const quickRepliesDiv = document.getElementById('quickReplies');
    if (quickRepliesDiv) {
        quickRepliesDiv.style.display = 'none';
    }
}

function showQuickReplies() {
    const quickRepliesDiv = document.getElementById('quickReplies');
    if (quickRepliesDiv && !hasSentMessage) {
        quickRepliesDiv.style.display = 'flex';
    }
}

function addFollowUpReplies() {
    // Remove existing follow-up replies to avoid duplicates
    const existingFollowUp = document.querySelector('.follow-up-replies');
    if (existingFollowUp) {
        existingFollowUp.remove();
    }
    
    const followUpDiv = document.createElement('div');
    followUpDiv.className = 'quick-replies follow-up-replies';
    followUpDiv.innerHTML = `
        <div class="quick-reply-group">
            <div class="quick-reply-title">💡 Want to continue?</div>
            <button class="quick-reply" data-action="showGenres">🎭 Try different genre</button>
            <button class="quick-reply" data-message="how to borrow">📖 How to borrow?</button>
            <button class="quick-reply" data-message="what's popular">⭐ Popular Books</button>
            <button class="quick-reply" data-message="highly rated">🏆 Highly Rated Books</button>
            <button class="quick-reply" data-message="newly added">🆕 Newly Added Books</button>
            <button class="quick-reply" data-action="searchByTitle">🔍 Search by Title</button>
            <button class="quick-reply" data-action="searchByAuthor">✍️ Search by Author</button>
            <button class="quick-reply" data-message="personalized recommendations">🎯 My Recommendations</button>
        </div>
    `;
    
    // Attach event listeners to new buttons
    const buttons = followUpDiv.querySelectorAll('.quick-reply');
    buttons.forEach(btn => {
        const action = btn.getAttribute('data-action');
        const message = btn.getAttribute('data-message');
        
        if (action === 'showGenres') {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                followUpDiv.remove();
                showGenreSelection();
            });
        } else if (action === 'searchByTitle') {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                followUpDiv.remove();
                appendMsg('I want to search by title ', 'user');
                input.value = 'Search for ';
                input.focus();
            });
        } else if (action === 'searchByAuthor') {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                followUpDiv.remove();
                appendMsg('I want to search by author ', 'user');
                input.value = 'Find books by ';
                input.focus();
            });
        } else if (message) {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                followUpDiv.remove();
                sendMessage(message);
            });
        }
    });
    
    msgs.appendChild(followUpDiv);
    followUpDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

async function sendMessage(messageText = null) {
    const text = messageText || input.value.trim();
    if (!text || isLoading) return;
    
    // Hide quick replies after first message
    if (!hasSentMessage && !messageText) {
        hasSentMessage = true;
        hideQuickReplies();
    }
    
    // Remove any existing follow-up or genre selection
    const existingFollowUp = document.querySelector('.follow-up-replies');
    if (existingFollowUp) existingFollowUp.remove();
    const existingGenre = document.querySelector('.genre-selection');
    if (existingGenre) existingGenre.remove();
    
    // Disable input while processing
    isLoading = true;
    send.disabled = true;
    input.disabled = true;
    
    // Show user message
    appendMsg(text, 'user');
    if (!messageText) {
        input.value = '';
    }
    
    // Show typing indicator
    showTypingIndicator();
    
    try {
        const formData = new FormData();
        formData.append('message', text);
        
        const response = await fetch('chatbot_api.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        removeTypingIndicator();
        
        if (data.reply) {
            appendMsg(data.reply, 'bot');
            // ALWAYS show follow-up bubbles after every response
            addFollowUpReplies();
        } else {
            appendMsg("Sorry, I couldn't process your request. Please try again! 📚", 'bot');
            addFollowUpReplies();
        }
    } catch (error) {
        console.error('Error:', error);
        removeTypingIndicator();
        appendMsg("Oops! Something went wrong. Please try again later. 💡", 'bot');
        addFollowUpReplies();
    } finally {
        // Re-enable input
        isLoading = false;
        send.disabled = false;
        input.disabled = false;
        input.focus();
    }
}

// Fetch and display genres from database
async function loadGenres() {
    try {
        const formData = new FormData();
        formData.append('get_genres', '1');
        
        const response = await fetch('chatbot_api.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.genres && data.genres.length > 0) {
            const container = document.getElementById('genre-buttons-loading');
            if (container) {
                // Clear loading text
                container.innerHTML = '';
                
                // Create buttons for each genre
                data.genres.forEach(genre => {
                    const button = document.createElement('button');
                    button.className = 'quick-reply';
                    const genreName = genre.category;
                    button.setAttribute('data-message', `recommend ${genreName.toLowerCase()} books`);
                    
                    let emoji = '📖';
                    
                    button.textContent = `${emoji} ${genre.category}`;
                    
                    // Add click event
                    button.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const msg = button.getAttribute('data-message');
                        sendMessage(msg);
                    });
                    
                    container.appendChild(button);
                });
            }
        }
    } catch (error) {
        console.error('Error loading genres:', error);
        const container = document.getElementById('genre-buttons-loading');
        if (container) {
            container.innerHTML = 'Failed to load genres. Please refresh.';
        }
    }
}

// Also update the showGenreSelection() function to use dynamic genres
async function showGenreSelection() {
    const genreDiv = document.createElement('div');
    genreDiv.className = 'quick-replies genre-selection';
    genreDiv.innerHTML = `
        <div class="quick-reply-group">
            <div class="quick-reply-title">📚 By Genre:</div>
            <div class="genre-loading">Loading genres...</div>
        </div>
    `;
    
    msgs.appendChild(genreDiv);
    genreDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    
    // Fetch and populate genres
    try {
        const formData = new FormData();
        formData.append('get_genres', '1');
        
        const response = await fetch('chatbot_api.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.genres && data.genres.length > 0) {
            const loadingDiv = genreDiv.querySelector('.genre-loading');
            if (loadingDiv) {
                loadingDiv.remove();
            }
            
            const groupDiv = genreDiv.querySelector('.quick-reply-group');
            
            data.genres.forEach(genre => {
                const button = document.createElement('button');
                button.className = 'quick-reply';
                const genreName = genre.category;
                button.setAttribute('data-message', `recommend ${genreName.toLowerCase()} books`);
                
                let emoji = '📖';
                button.textContent = `${emoji} ${genre.category}`;
                
                button.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const msg = button.getAttribute('data-message');
                    genreDiv.remove();
                    sendMessage(msg);
                });
                
                groupDiv.appendChild(button);
            });
        }
    } catch (error) {
        console.error('Error loading genres:', error);
        const loadingDiv = genreDiv.querySelector('.genre-loading');
        if (loadingDiv) {
            loadingDiv.innerHTML = 'Failed to load genres. Please try again.';
        }
    }
}

// Event listeners for initial quick reply buttons
document.querySelectorAll('.quick-reply').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const msg = btn.getAttribute('data-message');
        const action = btn.getAttribute('data-action');
        
        if (action === 'searchByTitle') {
            appendMsg('I want to search by title: ', 'user');
            input.value = 'Search for ';
            input.focus();
        } else if (action === 'searchByAuthor') {
            appendMsg('I want to search by author: ', 'user');
            input.value = 'Find books by ';
            input.focus();
        } else if (msg) {
            sendMessage(msg);
        }
    });
});

// Load genres when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadGenres();
});

send.addEventListener('click', () => sendMessage());
input.addEventListener('keydown', e => { if (e.key === 'Enter') sendMessage(); });

// Reset quick replies when chat is closed and reopened
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.attributeName === 'class') {
            if (!win.classList.contains('open')) {
                // Chat closed - reset for next open
                setTimeout(() => {
                    hasSentMessage = false;
                    const quickRepliesDiv = document.getElementById('quickReplies');
                    if (quickRepliesDiv) {
                        quickRepliesDiv.style.display = 'flex';
                    }
                    // Remove any follow-up replies AND genre selections
                    document.querySelectorAll('.follow-up-replies, .genre-selection').forEach(el => el.remove());
                }, 300);
            } else {
                // Chat opened - ensure quick replies are visible if no messages sent yet
                if (!hasSentMessage) {
                    const quickRepliesDiv = document.getElementById('quickReplies');
                    if (quickRepliesDiv) {
                        quickRepliesDiv.style.display = 'flex';
                    }
                }
            }
        }
    });
});

observer.observe(win, { attributes: true });
</script>

</body>
</html>