<?php
// includes/librarians_header.php
// Specialized header for librarians with dashboard, profile, and notifications only

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$active_tab = $active_tab ?? 'dashboard';

// ── Database connection ───────────────────────────────────────────────────────
require_once __DIR__ . '/../db.php';

// ── Logged-in user ────────────────────────────────────────────────────────────
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

$logged_in_username = $_SESSION['username'];

// Fetch the logged-in user's ID and display name from the users table.
$stmt = $pdo->prepare('SELECT id, name, user_type_id FROM users WHERE username = ? LIMIT 1');
$stmt->execute([$logged_in_username]);
$user_row = $stmt->fetch();

if ($user_row) {
    $logged_in_user_id = $user_row['id'];
    $user_name = $user_row['name'];
    $logged_in_user_type_id = $user_row['user_type_id'];
    
    // Fetch user type name for convenience
    $typeStmt = $pdo->prepare('SELECT type FROM user_type WHERE id = ?');
    $typeStmt->execute([$logged_in_user_type_id]);
    $userType = $typeStmt->fetch();
    $logged_in_user_type = $userType['type'] ?? 'user';
} else {
    $logged_in_user_id = 2;
    $user_name = 'Guest';
    $logged_in_user_type = 'user';
}

// ── Librarian-specific statistics ─────────────────────────────────────────────
// STAT 1: Pending Borrows
$stmt = $pdo->query('SELECT COUNT(*) FROM borrow_requests WHERE book_status_id = 1');
$pending_borrows = (int) $stmt->fetchColumn();

// STAT 2: Pending Returns
$stmt = $pdo->query('SELECT COUNT(*) FROM borrow_requests WHERE book_status_id = 2');
$pending_returns = (int) $stmt->fetchColumn();

// STAT 3: Total Books
$stmt = $pdo->query('SELECT COUNT(*) FROM books');
$total_books = (int) $stmt->fetchColumn();

// STAT 4: Total Users (only regular users, user_type_id = 3)
$stmt = $pdo->query('SELECT COUNT(*) FROM users WHERE user_type_id = 3');
$total_users = (int) $stmt->fetchColumn();

// ── Notification bell dot ─────────────────────────────────────────────────────
// Count unread notifications for the logged-in user
$stmt = $pdo->prepare(
    'SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0'
);
$stmt->execute([$logged_in_user_id]);
$unread_notifs = (int) $stmt->fetchColumn();

// ── Admin / Librarian page tabs ───────────────────────────────────────────────────────
$tabs = [
    'dashboard'     => ['label' => 'Dashboard',      'href' => 'librarians_main.php'],
    'library'       => ['label' => 'Library',        'href' => 'library.php'],
    'history'       => ['label' => 'History',        'href' => 'book_history.php'],
];

if ($logged_in_user_type_id == 1) {
    $tabs['panel'] = ['label' => 'Panel', 'href' => 'admin_panel.php'];
}

$tabs = array_merge($tabs, [
    'profile'       => ['label' => 'Profile',        'href' => 'profile.php'],
    'notifications' => ['label' => 'Notifications',  'href' => 'notifications.php'],
]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Library Hub - Librarians</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- ===== NAVBAR ===== -->
<nav class="navbar">
  <div class="navbar-brand">
    <div class="logo-icon">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
      </svg>
    </div>
    <div class="brand-text">
      <h1>Library Hub</h1>
      <span>Librarian Dashboard</span>
    </div>
  </div>
  <div class="navbar-actions">
    <a href="notifications.php" class="notif-btn">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
        <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
      </svg>
      <?php if ($unread_notifs > 0): ?>
        <span class="badge"><?php echo $unread_notifs > 99 ? '99+' : $unread_notifs; ?></span>
      <?php endif; ?>
    </a>
    <div class="user-info">
        <a href="profile.php" class="profile-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
            <?= htmlspecialchars($user_name) ?>
            <span style="font-size: 11px; background: #e5e7eb; padding: 2px 6px; border-radius: 12px; margin-left: 8px;">
              <?php 
              // Get user role from session or database
              if (isset($_SESSION['user_type_id'])) {
                  if ($_SESSION['user_type_id'] == 1) {
                      echo 'Admin';
                  } elseif ($_SESSION['user_type_id'] == 2) {
                      echo 'Librarian';
                  }
              } else {
                  echo 'User';
              }
              ?>
            </span>
        </a>
    </div>
    <a href="logout.php" class="logout-btn" onclick="return confirm('Are you sure you want to logout?');">Logout</a>
  </div>
</nav>

<!-- ===== LIBRARIAN STATS BAR ===== -->
<div class="stats-section">

  <!-- Pending Borrows -->
  <div class="stat-card">
    <div class="stat-card-header">
      <span class="stat-label">Pending Borrows</span>
      <svg class="stat-icon" width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/>
      </svg>
    </div>
    <div class="stat-value"><?= number_format($pending_borrows) ?></div>
    <div class="stat-sub">Awaiting confirmation</div>
  </div>

  <!-- Pending Returns -->
  <div class="stat-card">
    <div class="stat-card-header">
      <span class="stat-label">Pending Returns</span>
      <svg class="stat-icon" width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/>
        <path d="M3 3v5h5"/>
      </svg>
    </div>
    <div class="stat-value"><?= number_format($pending_returns) ?></div>
    <div class="stat-sub">Waiting to return</div>
  </div>

  <!-- Total Books -->
  <div class="stat-card">
    <div class="stat-card-header">
      <span class="stat-label">Total Books</span>
      <svg class="stat-icon" width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
      </svg>
    </div>
    <div class="stat-value"><?= number_format($total_books) ?></div>
    <div class="stat-sub">In library system</div>
  </div>

  <!-- Total Users -->
  <div class="stat-card">
    <div class="stat-card-header">
      <span class="stat-label">Total Users</span>
      <svg class="stat-icon" width="18" height="18" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
        <circle cx="9" cy="7" r="4"/>
        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
      </svg>
    </div>
    <div class="stat-value"><?= number_format($total_users) ?></div>
    <div class="stat-sub">Active members</div>
  </div>

</div>

<!-- ===== PAGE TABS ===== -->
<div class="page-tabs">
  <?php foreach ($tabs as $key => $tab): ?>
    <a href="<?= $tab['href'] ?>"
       class="<?= $active_tab === $key ? 'active' : '' ?>">
      <?= htmlspecialchars($tab['label']) ?>
    </a>
  <?php endforeach; ?>
</div>

<div class="main-content">
